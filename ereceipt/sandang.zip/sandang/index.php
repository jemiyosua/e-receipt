<?php

require_once('koneksi.php');

include('header.php');

$q = "SELECT COUNT(1) AS CNT_TOTAL FROM TAGIHAN";
$sql = mysqli_query($conn, $q);
$row = mysqli_fetch_assoc($sql);

$TOTAL = $row['CNT_TOTAL'];

?>


<div class="page-wrap">

    <?php include('sidebar.php') ?>

    <div class="main-content">
        <div class="container-fluid">
            <div class="row clearfix">
                <div class="col-lg-12 col-md-6 col-sm-12">
                    <div class="jumbotron">
                        <h1 class="display-4">Welcome!</h1>
                        <p class="lead">This site will help you to create your receipt payment for your
                            boarding house</p>
                        <hr class="my-4">
                        <!-- <p>It uses utility classes for typography and spacing to space content out within the larger container.</p> -->
                        <a class="btn btn-primary btn-lg" href="indexInvoice.php" type="button"><i class="fas fa-file-invoice-dollar"></i> Create Your Payment Here</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include('sidebarMessage.php') ?>

    <?php include('footer1.php') ?>

</div>
</div>

<?php

include('panelSetting.php');

include('footer.php')

?>