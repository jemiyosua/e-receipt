<?php $TAHUN = date('Y'); ?>

<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">Copyright © <?= $TAHUN ?> Kost Sandang D5. All Rights Reserved.</span>
        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">Created by <b>Psyc0d3path</b></span>
    </div>
</footer>