<?php

$servername = "localhost";
$database = "sandang";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password, $database);
