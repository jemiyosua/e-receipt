<?php

$servername = "localhost";
$database = "ereceipt_sandang";
$username = "ereceipt_user";
$password = "uFLrLszJAKxK";

$conn = mysqli_connect($servername, $username, $password, $database);
