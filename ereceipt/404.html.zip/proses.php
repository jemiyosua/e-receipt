<?php

require_once('koneksi.php');

session_start();

if (isset($_POST['tambah'])) {

    if (isset($_GET['id'])) {
        $ID_USER = $_GET['id'];
    }

    $_SESSION['pos'] = $_POST;

    function generateRandomString($length = 20)
    {
        return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
    }

    $RANDOM = generateRandomString();

    $NAMA = $_POST['nama'];
    $EMAIL = $_POST['email'];
    $TANGGAL_BAYAR = $_POST['tanggalBayar'];
    $BULAN_REIMBURSE = $_POST['bulanReimburse'];
    $JUMLAH_BAYAR = $_POST['jumlahBayar'];
    $KETERANGAN = $_POST['keterangan'];

    $NAMA_KOST = $_POST['namaKost'];
    $ALAMAT_KOST = $_POST['alamatKost'];
    $HP_KOST = $_POST['hpKost'];
    $EMAIL_KOST = $_POST['emailKost'];
    $WEB_KOST = $_POST['websiteKost'];
    $PEMILIK_KOST = $_POST['pemilikKost'];

    $q = "INSERT INTO TAGIHAN (ID_USER, PAYMENT_ID, NAMA, TANGGAL_BAYAR, BULAN_REIMBURSE, TOTAL_BAYAR, KETERANGAN, TGL_INPUT, NAMA_KOST, ALAMAT_KOST, NO_TELEPON, EMAIL_KOST, WEBSITE_KOST, NAMA_PEMILIK)
        VALUES ('$ID_USER', '$RANDOM', '$NAMA', '$TANGGAL_BAYAR', '$BULAN_REIMBURSE', '$JUMLAH_BAYAR', '$KETERANGAN', SYSDATE(), '$NAMA_KOST', '$ALAMAT_KOST', '$HP_KOST', '$EMAIL_KOST', '$WEB_KOST', '$PEMILIK_KOST');";
    $sql = mysqli_query($conn, $q);

    if ($sql) {
        $_SESSION['pesan'] = "Bukti Pembayaran Berhasil Ditambahkan!";
        header('location: indexInvoice.php');
    } else {
        $_SESSION['pesanError'] = "Bukti Pembayaran Gagal Ditambahkan!";
        header('location: indexInvoice.php');
    }

    // $qNama = "SELECT COUNT(1) AS CNT FROM TAGIHAN WHERE NAMA = '$NAMA'";
    // $sqlNama = mysqli_query($conn, $qNama);
    // $row = mysqli_fetch_assoc($sqlNama);

    // $CNT = $row['CNT'];

    // if ($CNT > 0) {
    //     $_SESSION['pesanError'] = "Name Already Exists, Please Check Submission History on History Name!";
    // $_SESSION['nama'] = $NAMA;
    // $_SESSION['tanggalBayar'] = $TANGGAL_BAYAR;
    // $_SESSION['bulanReimburse'] = $BULAN_REIMBURSE;
    // $_SESSION['jumlahBayar'] = $JUMLAH_BAYAR;
    // $_SESSION['keterangan'] = $KETERANGAN;
    // $_SESSION['namaKost'] = $NAMA_KOST;
    // $_SESSION['alamatKost'] = $ALAMAT_KOST;
    // $_SESSION['hpKost'] = $HP_KOST;
    // $_SESSION['emailKost'] = $EMAIL_KOST;
    // $_SESSION['websiteKost'] = $WEB_KOST;
    // $_SESSION['pemilikKost'] = $PEMILIK_KOST;
    // header('location: tambahData.php');
    // } else {

    // }

    // TAMBAH DATA TIAP NAMA
    // } else if (isset($_POST['tambahAda'])) {

    //     function generateRandomString($length = 20)
    //     {
    //         return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
    //     }

    //     $RANDOM = generateRandomString();

    //     $NAMA = $_POST['nama'];
    //     $TANGGAL_BAYAR = $_POST['tanggalBayar'];
    //     $BULAN_REIMBURSE = $_POST['bulanReimburse'];
    //     $JUMLAH_BAYAR = $_POST['jumlahBayar'];
    //     $KETERANGAN = $_POST['keterangan'];

    //     $NAMA_KOST = $_POST['namaKost'];
    //     $ALAMAT_KOST = $_POST['alamatKost'];
    //     $HP_KOST = $_POST['hpKost'];
    //     $EMAIL_KOST = $_POST['emailKost'];
    //     $WEB_KOST = $_POST['websiteKost'];
    //     $PEMILIK_KOST = $_POST['pemilikKost'];

    //     $q = "INSERT INTO TAGIHAN (PAYMENT_ID, NAMA, TANGGAL_BAYAR, BULAN_REIMBURSE, TOTAL_BAYAR, KETERANGAN, TGL_INPUT, NAMA_KOST, ALAMAT_KOST, NO_TELEPON, EMAIL_KOST, WEBSITE_KOST, NAMA_PEMILIK)
    //     VALUES ('$RANDOM', '$NAMA', '$TANGGAL_BAYAR', '$BULAN_REIMBURSE', '$JUMLAH_BAYAR', '$KETERANGAN', SYSDATE(), '$NAMA_KOST', '$ALAMAT_KOST', '$HP_KOST', '$EMAIL_KOST', '$WEB_KOST', '$PEMILIK_KOST');";
    //     $sql = mysqli_query($conn, $q);

    //     if ($sql) {
    //         $_SESSION['pesan'] = "Bukti Pembayaran Berhasil Ditambahkan!";
    //         header('location: detailTagihan.php?nama=' . $NAMA);
    //     } else {
    //         $_SESSION['pesanError'] = "Bukti Pembayaran Gagal Ditambahkan!";
    //         header('location: detailTagihan.php?nama=' . $NAMA);
    //     }
}
