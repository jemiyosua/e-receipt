<?php

session_start();

include('headerLogin.php');

$tahunIni = date('Y');

if (isset($_SESSION['username']) && (isset($_SESSION['password']))) {

    header('location:index_.php');
}

?>

<body class="my-login-page">
    <section class="h-100">
        <div class="container h-100">
            <div class="row justify-content-md-center h-100">
                <div class="card-wrapper">
                    <div style="padding-top: 80px;" align="center">
                        <img src="img/bill.png" alt="logo" style="width: 80px;">
                    </div>
                    <div style="padding-top: 10px;"></div>
                    <h4 style="text-align: center;">E - Receipt</h4>

                    <div style="padding-bottom: 10px;"></div>

                    <?php
                    if (isset($_SESSION['pesan'])) {
                        echo "<div class='alert alert-success' role='alert' style='border-radius:10px;'>" . $_SESSION['pesan'] . "</div>";
                        unset($_SESSION['pesan']);
                    } else if (isset($_SESSION['pesanError'])) {
                        echo "<div class='alert alert-warning' role='alert' style='border-radius:10px;'>" . $_SESSION['pesanError'] . "</div>";
                        unset($_SESSION['pesanError']);
                    }
                    ?>

                    <div class="card fat">
                        <div class="card-body">
                            <h4 class="card-title">Register</h4>
                            <div class="alert alert-info" role="alert">
                                Register using your <b>active email</b> for your receipt payment will send to your email
                            </div>
                            <form method="POST" action="prosesRegister.php" class="my-login-validation" novalidate="">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input id="email" type="email" class="form-control" name="email" required autofocus>
                                    <div class="invalid-feedback">
                                        Username is required
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Create Your Password
                                    </label>
                                    <input id="password" type="password" class="form-control" name="password" required data-eye>
                                    <div class="invalid-feedback">
                                        Password is required
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Confirm Your Password
                                    </label>
                                    <input id="password2" type="password" class="form-control" name="password2" required data-eye>
                                    <div class="invalid-feedback">
                                        Password is required
                                    </div>
                                </div>

                                <div class="form-group m-0">
                                    <button type="submit" class="btn btn-primary btn-block" name="register">
                                        Register
                                    </button>
                                </div>
                            </form>

                            <div style="padding-top: 30px;">Already Have an Account? <a href="index.php" style="text-decoration: none;">Login</a></div>

                        </div>
                    </div>
                    <div class="footer">
                        Copyright &copy; <?= $tahunIni ?> &mdash; E - Receipt by Psycodepath
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php

    include('footerLogin.php');

    ?>