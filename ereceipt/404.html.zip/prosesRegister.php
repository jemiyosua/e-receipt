<?php

require_once('koneksi.php');

session_start();

if (isset($_POST['register'])) {

    $EMAIL = $_POST['email'];
    $PASSWORD = $_POST['password'];
    $PASSWORD2 = $_POST['password2'];

    $q = "SELECT COUNT(*) AS CNT_LOGIN FROM LOGIN WHERE EMAIL = '$EMAIL' ";
    $sql = mysqli_query($conn, $q);
    $row = mysqli_fetch_assoc($sql);

    $CNT_LOGIN = $row['CNT_LOGIN'];

    if ($CNT_LOGIN > 0) {
        $_SESSION['pesanError'] = "Email is already taken! use another email.";
        header('location:register.php');
    } else if ($PASSWORD != $PASSWORD2) {
        $_SESSION['pesanError'] = "Your password is doesn't match!, check your password and try again.";
        header('location:register.php');
    } else {
        $q = "INSERT INTO LOGIN (EMAIL, PASSWORD)
                        VALUES ('$EMAIL', '$PASSWORD'); ";
        $sql = mysqli_query($conn, $q);

        if ($sql) {
            $_SESSION['pesan'] = "Congratulation! your account was created, please login for more information.";
            header('location:index.php');
        } else {
            $_SESSION['pesanError'] = "Something went wrong when create your account, try again later.";
            header('location:register.php');
        }
    }
}
