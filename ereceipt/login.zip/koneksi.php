<?php

$servername = "localhost";
$database = "portal";
$username = "root";
$password = "";

$conn = mysqli_connect($servername, $username, $password, $database);
